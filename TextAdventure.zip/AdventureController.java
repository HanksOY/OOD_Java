import java.util.Scanner;

/**
 * Controller class for the "Escape the Laboratory" adventure game.
 * Handles input parsing and game logic.
 */
public class AdventureController {
    private AdventureModel model;
    private AdventureView view;
    private Scanner scanner;

    public AdventureController(AdventureModel model, AdventureView view) {
        this.model = model;
        this.view = view;
        this.scanner = new Scanner(System.in);
    }

    /**
     * Main game loop - runs while game is active.
     */
    public void startGame() {
        view.displayIntro();

        while (model.isGameRunning()) {
            view.promptUser();
            String input = scanner.nextLine();
            parseAndExecute(input);
        }
        scanner.close();
    }

    /**
     * CRITICAL: Custom parsing WITHOUT regex, split(), or StringTokenizer.
     * Uses indexOf() and substring() to separate verb from noun.
     */
    public void parseAndExecute(String input) {
        // Step 1: Trim whitespace from both ends
        String trimmed = input.trim();

        // Step 2: Handle empty input
        if (trimmed.isEmpty()) {
            view.displayError("Please enter a command.");
            return;
        }

        // Step 3: Convert to uppercase for case-insensitive comparison
        String upperInput = trimmed.toUpperCase();

        // Step 4: Find the first space using indexOf (NOT split or regex!)
        int spaceIndex = upperInput.indexOf(' ');

        String verb;
        String noun;

        // Step 5: If no space found, it's a single-word input (error case)
        if (spaceIndex == -1) {
            view.displayError("Please enter a command with two words (e.g., LOOK ROOM).");
            return;
        }

        // Step 6: Extract verb (everything before first space)
        verb = upperInput.substring(0, spaceIndex);

        // Step 7: Extract noun (everything after first space, trimmed)
        // This handles multi-word nouns by taking the rest of the string
        noun = upperInput.substring(spaceIndex + 1).trim();

        // Step 8: Handle case where noun is empty after trimming
        if (noun.isEmpty()) {
            view.displayError("Please specify what you want to " + verb.toLowerCase() + ".");
            return;
        }

        // Step 9: Validate verb against model's vocabulary
        if (!model.isValidVerb(verb)) {
            view.displayError("I don't understand the verb '" + verb + "'.");
            return;
        }

        // Step 10: Validate noun against model's vocabulary
        if (!model.isValidNoun(noun)) {
            view.displayError("I don't know what '" + noun + "' is.");
            return;
        }

        // Step 11: Process the valid command
        processCommand(verb, noun);
    }

    /**
     * Handles specific game interactions based on verb-noun combinations.
     */
    public void processCommand(String verb, String noun) {
        switch (verb) {
            case "LOOK":
            case "EXAMINE":
                handleLook(noun);
                break;
            case "TAKE":
                handleTake(noun);
                break;
            case "USE":
                handleUse(noun);
                break;
            case "OPEN":
                handleOpen(noun);
                break;
            case "GO":
                handleGo(noun);
                break;
            case "INVENTORY":
                handleInventory();
                break;
            default:
                view.displayError("I can't do that.");
        }
    }

    private void handleLook(String noun) {
        switch (noun) {
            case "ROOM":
            case "AROUND":
                view.displayOutput("You see a TABLE, COMPUTER, COAT, FLASK, WINDOW, and DOOR.");
                break;
            case "TABLE":
                view.displayOutput("A metal table. There's nothing on it.");
                break;
            case "COMPUTER":
                view.displayOutput("An old computer. The screen reads: 'KEYCARD IN COAT POCKET'.");
                break;
            case "COAT":
                if (!model.hasKeycard()) {
                    view.displayOutput("A white lab coat. Something bulges in the pocket...");
                } else {
                    view.displayOutput("An empty lab coat.");
                }
                break;
            case "FLASK":
                view.displayOutput("A flask with green bubbling liquid. Probably not safe to drink.");
                break;
            case "WINDOW":
                view.displayOutput("A small window. It's barred from outside. No escape here.");
                break;
            case "DOOR":
                if (model.isDoorUnlocked()) {
                    view.displayOutput("The door is unlocked! You can GO DOOR to escape.");
                } else {
                    view.displayOutput("A heavy door with an electronic card reader.");
                }
                break;
            case "KEYCARD":
                if (model.hasItem("KEYCARD")) {
                    view.displayOutput("A plastic keycard with 'ACCESS LEVEL 1' printed on it.");
                } else {
                    view.displayOutput("You don't have a keycard.");
                }
                break;
            default:
                view.displayOutput("Nothing special about that.");
        }
    }

    private void handleTake(String noun) {
        switch (noun) {
            case "KEYCARD":
                if (model.hasItem("KEYCARD")) {
                    view.displayOutput("You already have the keycard.");
                } else {
                    view.displayOutput("You search and find the KEYCARD in the coat pocket!");
                    model.addToInventory("KEYCARD");
                    model.setHasKeycard(true);
                }
                break;
            case "FLASK":
                view.displayOutput("Better not. It might be dangerous.");
                break;
            case "COAT":
                view.displayOutput("It's attached to the wall. Try searching it instead.");
                break;
            default:
                view.displayOutput("You can't take that.");
        }
    }

    private void handleUse(String noun) {
        switch (noun) {
            case "KEYCARD":
                if (model.hasItem("KEYCARD")) {
                    view.displayOutput("You swipe the keycard. The door clicks open!");
                    model.setDoorUnlocked(true);
                } else {
                    view.displayOutput("You don't have a keycard.");
                }
                break;
            case "COMPUTER":
                view.displayOutput("The computer displays: 'KEYCARD IN COAT POCKET'.");
                break;
            case "FLASK":
                view.displayOutput("You wisely decide not to drink mysterious chemicals.");
                break;
            default:
                view.displayOutput("You can't use that.");
        }
    }

    private void handleOpen(String noun) {
        switch (noun) {
            case "DOOR":
                if (model.isDoorUnlocked()) {
                    view.displayOutput("The door swings open! Freedom awaits!");
                    view.displayOutput("Type 'GO DOOR' to escape!");
                } else if (model.hasItem("KEYCARD")) {
                    view.displayOutput("Try 'USE KEYCARD' to unlock the door first.");
                } else {
                    view.displayOutput("The door is locked. You need a keycard.");
                }
                break;
            case "WINDOW":
                view.displayOutput("The window is barred. It won't budge.");
                break;
            default:
                view.displayOutput("You can't open that.");
        }
    }

    private void handleGo(String noun) {
        switch (noun) {
            case "DOOR":
                if (model.isDoorUnlocked()) {
                    view.displayWin();
                    model.setGameRunning(false);
                } else {
                    view.displayOutput("The door is locked.");
                }
                break;
            case "NORTH":
            case "SOUTH":
            case "EAST":
            case "WEST":
                view.displayOutput("You can't go that way. The only exit is the DOOR.");
                break;
            case "WINDOW":
                view.displayOutput("The window is barred. You can't escape through there.");
                break;
            default:
                view.displayOutput("You can't go there.");
        }
    }

    private void handleInventory() {
        if (model.getInventory().isEmpty()) {
            view.displayOutput("Your inventory is empty.");
        } else {
            view.displayOutput("Inventory: " + String.join(", ", model.getInventory()));
        }
    }
}

