import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Model class for the "Escape the Laboratory" adventure game.
 * Holds game state: location, inventory, vocabulary, and win condition.
 */
public class AdventureModel {
    private String currentLocation;
    private ArrayList<String> inventory;
    private List<String> validVerbs;
    private List<String> validNouns;
    private boolean gameRunning;
    private boolean hasKeycard;
    private boolean doorUnlocked;

    public AdventureModel() {
        this.currentLocation = "Laboratory";
        this.inventory = new ArrayList<>();
        this.gameRunning = true;
        this.hasKeycard = false;
        this.doorUnlocked = false;

        // Initialize valid verbs (5 unique)
        this.validVerbs = Arrays.asList("LOOK", "TAKE", "USE", "OPEN", "GO", "EXAMINE", "INVENTORY");

        // Initialize valid nouns (7 unique)
        this.validNouns = Arrays.asList(
            "FLASK", "KEYCARD", "DOOR", "TABLE", "WINDOW", "COMPUTER", "COAT",
            "ROOM", "AROUND", "NORTH", "SOUTH", "EAST", "WEST"
        );
    }

    public boolean isValidVerb(String verb) {
        return validVerbs.contains(verb.toUpperCase());
    }

    public boolean isValidNoun(String noun) {
        return validNouns.contains(noun.toUpperCase());
    }

    public void addToInventory(String item) {
        if (!inventory.contains(item.toUpperCase())) {
            inventory.add(item.toUpperCase());
        }
    }

    public void removeFromInventory(String item) {
        inventory.remove(item.toUpperCase());
    }

    public boolean hasItem(String item) {
        return inventory.contains(item.toUpperCase());
    }

    // Getters and Setters
    public String getCurrentLocation() { return currentLocation; }
    public void setCurrentLocation(String location) { this.currentLocation = location; }

    public ArrayList<String> getInventory() { return inventory; }

    public boolean isGameRunning() { return gameRunning; }
    public void setGameRunning(boolean running) { this.gameRunning = running; }

    public boolean hasKeycard() { return hasKeycard; }
    public void setHasKeycard(boolean has) { this.hasKeycard = has; }

    public boolean isDoorUnlocked() { return doorUnlocked; }
    public void setDoorUnlocked(boolean unlocked) { this.doorUnlocked = unlocked; }
}

