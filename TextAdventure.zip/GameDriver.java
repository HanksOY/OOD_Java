/**
 * Main driver class for "Escape the Laboratory" adventure game.
 * Instantiates MVC components and starts the game.
 */
public class GameDriver {
    public static void main(String[] args) {
        // Instantiate Model (game state and data)
        AdventureModel model = new AdventureModel();

        // Instantiate View (handles all display output)
        AdventureView view = new AdventureView();

        // Instantiate Controller (handles logic and user input)
        AdventureController controller = new AdventureController(model, view);

        // Start the game loop
        controller.startGame();
    }
}

