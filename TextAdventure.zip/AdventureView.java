/**
 * View class for the "Escape the Laboratory" adventure game.
 * Handles all output to the console.
 */
public class AdventureView {

    public void displayIntro() {
        System.out.println("ESCAPE THE LABORATORY");
        System.out.println("You wake up in a dim laboratory.");
        System.out.println("The door is locked with an electronic lock. ");
        System.out.println("Find the KEYCARD to escape!");
        System.out.println("Commands: LOOK <object>, TAKE <item>,");
        System.out.println("USE <item>, OPEN <object>,");
        System.out.println("GO <direction>, EXAMINE <object>");
        System.out.println("Type 'INVENTORY CHECK' to see your items.");
        System.out.println();
        displayOutput("You see a TABLE, a COMPUTER, a COAT hanging on a hook,");
        displayOutput("a FLASK on a shelf, a WINDOW, and a locked DOOR.");
        System.out.println();
    }

    public void displayOutput(String message) {
        System.out.println(message);
    }

    public void displayError(String message) {
        System.out.println("[ERROR] " + message);
    }

    public void promptUser() {
        System.out.print("> ");
    }

    public void displayWin() {
        System.out.println();
        System.out.println("CONGRATULATIONS!");
        System.out.println("You escaped the laboratory!");
        System.out.println("Thanks for playing!");
    }
}

